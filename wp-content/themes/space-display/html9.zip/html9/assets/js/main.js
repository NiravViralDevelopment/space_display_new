/* ==========================================================================
   SPACE DISPLAY — JS & GSAP INTERACTIVE CONTROLLER
   ========================================================================== */

document.addEventListener('DOMContentLoaded', function() {
  
  // ==========================================
  // 1. STICKY NAVBAR SCROLL EVENT
  // ==========================================
  const navbar = document.querySelector('.navbar-space');
  window.addEventListener('scroll', function() {
    if (window.scrollY > 40) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });

  // ==========================================
  // 2. HAMBURGER SIDEBAR NAVIGATION CONTROLLER
  // ==========================================
  const hamburgerBtn = document.getElementById('hamburgerBtn');
  const sidebarCloseBtn = document.getElementById('sidebarCloseBtn');
  const sidebarMenu = document.getElementById('sidebarMenu');
  const sidebarOverlay = document.getElementById('sidebarOverlay');
  const sidebarLinks = document.querySelectorAll('.sidebar-nav-link, #sidebarCta');

  function openSidebar() {
    if (sidebarMenu && sidebarOverlay) {
      sidebarMenu.classList.add('active');
      sidebarOverlay.classList.add('active');
      document.body.style.overflow = 'hidden';

      // Animate sidebar links sequentially with GSAP
      if (typeof gsap !== 'undefined') {
        gsap.fromTo('.sidebar-nav-link', 
          { opacity: 0, y: 30 },
          { opacity: 1, y: 0, duration: 0.5, stagger: 0.06, delay: 0.15, ease: 'power2.out' }
        );
        gsap.fromTo('.sidebar-footer',
          { opacity: 0, y: 20 },
          { opacity: 1, y: 0, duration: 0.5, delay: 0.5, ease: 'power2.out' }
        );
      }
    }
  }

  function closeSidebar() {
    if (sidebarMenu && sidebarOverlay) {
      sidebarMenu.classList.remove('active');
      sidebarOverlay.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  if (hamburgerBtn) {
    hamburgerBtn.addEventListener('click', openSidebar);
  }
  if (sidebarCloseBtn) {
    sidebarCloseBtn.addEventListener('click', closeSidebar);
  }
  if (sidebarOverlay) {
    sidebarOverlay.addEventListener('click', closeSidebar);
  }

  sidebarLinks.forEach(link => {
    link.addEventListener('click', closeSidebar);
  });

  window.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && sidebarMenu && sidebarMenu.classList.contains('active')) {
      closeSidebar();
    }
  });

  // ==========================================
  // 3. CUSTOM DESKTOP CURSOR
  // ==========================================
  // const cursorDot = document.querySelector('.custom-cursor');
  // const cursorFollower = document.querySelector('.custom-cursor-follower');
  // const cursorText = document.querySelector('.cursor-text');

  // if (window.innerWidth > 991 && cursorDot && cursorFollower) {
  //   let mouseX = 0, mouseY = 0;
  //   let followerX = 0, followerY = 0;

  //   window.addEventListener('mousemove', function(e) {
  //     mouseX = e.clientX;
  //     mouseY = e.clientY;
  //     cursorDot.style.left = mouseX + 'px';
  //     cursorDot.style.top = mouseY + 'px';
  //   });

  //   function animateCursor() {
  //     followerX += (mouseX - followerX) * 0.15;
  //     followerY += (mouseY - followerY) * 0.15;
  //     cursorFollower.style.left = followerX + 'px';
  //     cursorFollower.style.top = followerY + 'px';
  //     requestAnimationFrame(animateCursor);
  //   }
  //   animateCursor();

  //   // Hover interactive elements
  //   const hoverElements = document.querySelectorAll('a, button, .spotlight-card, .service-item, .pavilion-hero-card, .pavilion-mini-card');
  //   hoverElements.forEach(el => {
  //     el.addEventListener('mouseenter', function() {
  //       document.body.classList.add('cursor-expanded');
  //       if (el.getAttribute('data-cursor')) {
  //         cursorText.textContent = el.getAttribute('data-cursor');
  //       } else {
  //         cursorText.textContent = 'VIEW';
  //       }
  //     });
  //     el.addEventListener('mouseleave', function() {
  //       document.body.classList.remove('cursor-expanded');
  //       cursorText.textContent = '';
  //     });
  //   });
  // }

  // ==========================================
  // 4. FULL-SCREEN HERO SLIDER & TEXT STAGGER CONTROLLER
  // ==========================================
  const heroSlides = document.querySelectorAll('.hero-slide');
  const prevBtn = document.querySelector('.btn-hero-prev');
  const nextBtn = document.querySelector('.btn-hero-next');
  const pagLines = document.querySelectorAll('.hero-pag-line');

  const counterCurrent = document.querySelector('.hero-counter-current');
  const counterTotal = document.querySelector('.hero-counter-total');
  const projectNameEl = document.querySelector('.hero-project-name');
  const projectLocEl = document.querySelector('.hero-project-location');
  const heroSec = document.querySelector('.hero-section');

  // Trigger initial Hero entrance animation
  if (heroSec) {
    setTimeout(() => {
      heroSec.classList.add('is-loaded');
      if (typeof gsap !== 'undefined') {
        gsap.to('.hero-title-line span', {
          y: 0,
          opacity: 1,
          duration: 0.55,
          stagger: 0.15,
          ease: 'power3.out'
        });
        gsap.fromTo('.hero-stagger-sub', 
          { opacity: 0, y: 20 },
          { opacity: 1, y: 0, duration: 0.7, delay: 0.6, ease: 'power2.out' }
        );
      }
    }, 100);
  }

  if (heroSlides.length > 0) {
    let currentSlide = 0;
    const totalSlides = heroSlides.length;
    let autoplayTimer = null;
    const intervalTime = 2500;

    if (counterTotal) {
      counterTotal.textContent = String(totalSlides).padStart(2, '0');
    }

    function goToSlide(index, direction = 1) {
      if (index === currentSlide && heroSlides[index].classList.contains('active')) return;
      
      currentSlide = (index + totalSlides) % totalSlides;
      const nextSlideEl = heroSlides[currentSlide];

      // Update active slide classes
      heroSlides.forEach(slide => slide.classList.remove('active'));
      nextSlideEl.classList.add('active');

      // Update Counter
      if (counterCurrent) {
        counterCurrent.textContent = String(currentSlide + 1).padStart(2, '0');
      }

      // Re-trigger text stagger on slide change
      if (typeof gsap !== 'undefined') {
        gsap.fromTo('.hero-title-line span',
          { y: 50, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.75, stagger: 0.12, ease: 'power3.out' }
        );
      }

      // Update Project Metadata with smooth fade
      const projName = nextSlideEl.getAttribute('data-project');
      const projLoc = nextSlideEl.getAttribute('data-location');
      if (projectNameEl && projectLocEl) {
        if (typeof gsap !== 'undefined') {
          gsap.to([projectNameEl, projectLocEl], {
            opacity: 0,
            y: 8,
            duration: 0.25,
            onComplete: () => {
              projectNameEl.textContent = projName || '';
              projectLocEl.textContent = projLoc || '';
              gsap.to([projectNameEl, projectLocEl], { opacity: 1, y: 0, duration: 0.35 });
            }
          });
        } else {
          projectNameEl.textContent = projName || '';
          projectLocEl.textContent = projLoc || '';
        }
      }

      // Update Line Pagination Indicators
      pagLines.forEach((line, i) => {
        if (i === currentSlide) {
          line.classList.add('active');
        } else {
          line.classList.remove('active');
        }
      });
    }

    function nextSlide() {
      goToSlide(currentSlide + 1, 1);
    }

    function prevSlide() {
      goToSlide(currentSlide - 1, -1);
    }

    function startAutoplay() {
      stopAutoplay();
      autoplayTimer = setInterval(nextSlide, intervalTime);
    }

    function stopAutoplay() {
      if (autoplayTimer) {
        clearInterval(autoplayTimer);
        autoplayTimer = null;
      }
    }

    // Arrow Nav Events
    if (nextBtn) {
      nextBtn.addEventListener('click', function() {
        nextSlide();
        startAutoplay();
      });
    }
    if (prevBtn) {
      prevBtn.addEventListener('click', function() {
        prevSlide();
        startAutoplay();
      });
    }

    // Line Pagination Click Events
    pagLines.forEach((line, index) => {
      line.addEventListener('click', function() {
        goToSlide(index);
        startAutoplay();
      });
    });

    // Pause on Hover (Desktop)
    const heroSection = document.querySelector('.hero-section');
    if (heroSection && window.innerWidth > 991) {
      heroSection.addEventListener('mouseenter', stopAutoplay);
      heroSection.addEventListener('mouseleave', startAutoplay);
    }

    // Touch Swipe Support
    let touchStartX = 0;
    let touchEndX = 0;
    if (heroSection) {
      heroSection.addEventListener('touchstart', function(e) {
        touchStartX = e.changedTouches[0].screenX;
      }, { passive: true });

      heroSection.addEventListener('touchend', function(e) {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
      }, { passive: true });
    }

    function handleSwipe() {
      const swipeThreshold = 50;
      if (touchEndX < touchStartX - swipeThreshold) {
        nextSlide();
        startAutoplay();
      } else if (touchEndX > touchStartX + swipeThreshold) {
        prevSlide();
        startAutoplay();
      }
    }

    // Start initial autoplay
    startAutoplay();
  }

  // ==========================================
  // 5. SECTION 03 — CAPABILITIES EXPLORER CONTROLLER
  // ==========================================
  const capabilityItems = document.querySelectorAll('.capability-item');
  const activeServiceNum = document.getElementById('activeServiceNum');
  const activeServiceTitle = document.getElementById('activeServiceTitle');
  const serviceProgressFill = document.getElementById('serviceProgressFill');
  const totalCapabilities = capabilityItems.length || 8;

  function activateCapability(item) {
    if (!item) return;
    capabilityItems.forEach(el => el.classList.remove('active'));
    item.classList.add('active');

    const index = parseInt(item.getAttribute('data-index') || '1', 10);
    const title = item.getAttribute('data-title') || '';

    if (activeServiceNum) {
      activeServiceNum.textContent = String(index).padStart(2, '0');
    }
    if (activeServiceTitle) {
      activeServiceTitle.textContent = title;
    }
    if (serviceProgressFill) {
      const percentage = (index / totalCapabilities) * 100;
      serviceProgressFill.style.width = percentage + '%';
    }
  }

  capabilityItems.forEach(item => {
    item.addEventListener('mouseenter', function() {
      activateCapability(item);
    });

    item.addEventListener('click', function() {
      activateCapability(item);
    });
  });

  // ==========================================
  // 6. WORLDWIDE REGION FILTER TABS & MAP PINS & PROJECT PANEL
  // ==========================================
  const regionTabs = document.querySelectorAll('.btn-region-tab');
  const mapPins = document.querySelectorAll('.map-location-pin');
  const mapPanel = document.getElementById('mapProjectPanel');
  const mapPanelImg = document.getElementById('mapPanelImg');
  const mapPanelTitle = document.getElementById('mapPanelTitle');
  const mapPanelAddress = document.getElementById('mapPanelAddress');
  const mapPanelDesc = document.getElementById('mapPanelDesc');

  function updateMapProjectPanel(pin) {
    if (!pin || !mapPanel) return;

    const title = pin.getAttribute('data-title') || '';
    const address = pin.getAttribute('data-address') || '';
    const desc = pin.getAttribute('data-desc') || '';
    const img = pin.getAttribute('data-img') || '';

    // Active pin highlighting
    mapPins.forEach(p => p.classList.remove('active'));
    pin.classList.add('active');

    // Smooth animation transition
    mapPanel.classList.add('updating');

    setTimeout(() => {
      if (mapPanelTitle) mapPanelTitle.textContent = title;
      if (mapPanelAddress) mapPanelAddress.textContent = address;
      if (mapPanelDesc) mapPanelDesc.textContent = desc;
      if (mapPanelImg && img) mapPanelImg.src = img;

      mapPanel.classList.remove('updating');
    }, 200);
  }

  function filterWorldwidePins(selectedRegion) {
    const targetRegion = (selectedRegion || 'all').toLowerCase().trim();
    let firstMatchingPin = null;

    mapPins.forEach(pin => {
      const pinRegion = (pin.getAttribute('data-region') || '').toLowerCase().trim();
      
      let isMatch = false;
      if (targetRegion === 'all') {
        isMatch = true;
      } else if (targetRegion === 'tokyo' || targetRegion === 'japan') {
        isMatch = (pinRegion === 'tokyo' || pinRegion === 'japan');
      } else if (targetRegion === 'america' || targetRegion === 'north-america') {
        isMatch = (pinRegion === 'america' || pinRegion === 'north-america');
      } else {
        isMatch = (pinRegion === targetRegion);
      }

      if (isMatch) {
        pin.style.display = 'block';
        pin.style.visibility = 'visible';
        pin.style.opacity = '1';
        pin.style.pointerEvents = 'auto';
        if (!firstMatchingPin) {
          firstMatchingPin = pin;
        }
      } else {
        pin.style.display = 'none';
        pin.style.visibility = 'hidden';
        pin.style.opacity = '0';
        pin.style.pointerEvents = 'none';
        pin.classList.remove('active');
      }
    });

    if (firstMatchingPin) {
      updateMapProjectPanel(firstMatchingPin);
    }
  }

  if (mapPins.length > 0) {
    mapPins.forEach(pin => {
      pin.addEventListener('click', function() {
        if (this.style.display !== 'none') {
          updateMapProjectPanel(this);
        }
      });
    });

    regionTabs.forEach(tab => {
      tab.addEventListener('click', function() {
        const selectedRegion = this.getAttribute('data-region');

        regionTabs.forEach(t => t.classList.remove('active'));
        this.classList.add('active');

        filterWorldwidePins(selectedRegion);
      });
    });

    // Initialize initial state on load
    const activeTab = document.querySelector('.btn-region-tab.active');
    const initialRegion = activeTab ? activeTab.getAttribute('data-region') : 'all';
    filterWorldwidePins(initialRegion);
  }

  // ==========================================
  // 7. SCROLLTRIGGER / INTERSECTION OBSERVER REVEALS
  // ==========================================
  const observerOptions = {
    threshold: 0.15,
    rootMargin: '0px 0px -50px 0px'
  };

  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-inview');
        
        // Triggers for count-up numbers
        if (entry.target.classList.contains('stat-number') && !entry.target.classList.contains('counted')) {
          entry.target.classList.add('counted');
          animateCountUp(entry.target);
        }
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  document.querySelectorAll('.reveal-up, .stat-number').forEach(el => {
    revealObserver.observe(el);
  });

  // ==========================================
  // 8. SECTION 05 — COUNTRY PAVILIONS TAB FILTER CONTROLLER
  // ==========================================
  const pavilionTabs = document.querySelectorAll('.pavilion-tab-btn');
  const pavilionGridItems = document.querySelectorAll('.pavilion-grid-item');

  if (pavilionTabs.length > 0 && pavilionGridItems.length > 0) {
    function filterPavilions(filterVal) {
      pavilionGridItems.forEach(item => {
        const categories = (item.getAttribute('data-category') || '').split(' ');
        const isMatch = filterVal === 'all' || categories.includes(filterVal);

        if (isMatch) {
          item.classList.remove('is-hiding');
          item.style.display = 'block';
          setTimeout(() => {
            item.style.opacity = '1';
            item.style.transform = 'scale(1) translateY(0)';
          }, 40);
        } else {
          item.classList.add('is-hiding');
          setTimeout(() => {
            item.style.display = 'none';
          }, 350);
        }
      });
    }

    pavilionTabs.forEach(tab => {
      tab.addEventListener('click', function() {
        const filterVal = this.getAttribute('data-filter');

        // Update tab states & accessibility attributes
        pavilionTabs.forEach(t => {
          t.classList.remove('active');
          t.setAttribute('aria-selected', 'false');
          t.setAttribute('tabindex', '-1');
        });
        this.classList.add('active');
        this.setAttribute('aria-selected', 'true');
        this.setAttribute('tabindex', '0');

        filterPavilions(filterVal);
      });
    });

    // Initial filter execution for active tab
    const initialActiveTab = document.querySelector('.pavilion-tab-btn.active');
    if (initialActiveTab) {
      const initialFilter = initialActiveTab.getAttribute('data-filter');
      if (initialFilter) {
        filterPavilions(initialFilter);
      }
    }
  }

  // ==========================================
  // 9. SECTION 07 — CLIENTS LOGO MARQUEE
  // ==========================================
  (function initClientsMarquee() {
    const wrapper = document.querySelector('.clients-marquee-wrapper');
    const track = document.querySelector('.clients-marquee-track');
    if (!wrapper || !track) return;

    const firstGroup = track.querySelector('.clients-marquee-group');
    if (!firstGroup) return;

    track.classList.add('is-js-marquee');

    let offset = 0;
    let paused = false;
    let lastTime = performance.now();
    const speed = 42; // pixels per second

    function pause() { paused = true; }
    function resume() { paused = false; lastTime = performance.now(); }

    wrapper.addEventListener('mouseenter', pause);
    wrapper.addEventListener('mouseleave', resume);
    wrapper.addEventListener('touchstart', pause, { passive: true });
    wrapper.addEventListener('touchend', resume, { passive: true });

    function tick(now) {
      const delta = Math.min(now - lastTime, 64);
      lastTime = now;

      if (!paused) {
        const loopWidth = firstGroup.offsetWidth;
        if (loopWidth > 0) {
          offset += speed * (delta / 1000);
          if (offset >= loopWidth) {
            offset -= loopWidth;
          }
          track.style.transform = 'translate3d(' + (-offset) + 'px, 0, 0)';
        }
      }

      requestAnimationFrame(tick);
    }

    const images = track.querySelectorAll('img');
    let pending = 0;
    function start() {
      requestAnimationFrame(tick);
    }
    function onImgDone() {
      pending -= 1;
      if (pending <= 0) start();
    }

    images.forEach(function(img) {
      if (!img.complete) {
        pending += 1;
        img.addEventListener('load', onImgDone, { once: true });
        img.addEventListener('error', onImgDone, { once: true });
      }
    });

    if (pending === 0) start();
  })();

  // Count-up helper function
  function animateCountUp(el) {
    const targetText = el.getAttribute('data-count');
    const targetNum = parseInt(targetText, 10);
    if (isNaN(targetNum)) return;

    let start = 0;
    const duration = 2000;
    const stepTime = 20;
    const steps = duration / stepTime;
    const increment = targetNum / steps;

    const timer = setInterval(() => {
      start += increment;
      if (start >= targetNum) {
        el.textContent = targetText;
        clearInterval(timer);
      } else {
        el.textContent = Math.floor(start) + '+';
      }
    }, stepTime);
  }
});

